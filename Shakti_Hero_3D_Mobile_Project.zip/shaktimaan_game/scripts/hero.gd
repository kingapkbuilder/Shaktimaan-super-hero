extends CharacterBody3D

@export var move_speed := 12.0
@export var fly_speed := 16.0
@export var jump_velocity := 8.0
var flying := false
var power_percent := 100.0
var touch_actions: Dictionary = {}
var blast_cooldown := 0.0
var hero_visual: Node3D
var glow_mat: StandardMaterial3D

func _ready() -> void:
    _make_hero()
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.65
    capsule.height = 2.8
    collision.shape = capsule
    collision.position.y = 1.35
    add_child(collision)

func _make_hero() -> void:
    hero_visual = Node3D.new()
    add_child(hero_visual)
    var red := _material(Color(0.72, 0.035, 0.08))
    var gold := _material(Color(1.0, 0.62, 0.08), true)
    var skin := _material(Color(0.82, 0.57, 0.4))
    _add_capsule(hero_visual, Vector3(0, 1.35, 0), 0.46, 1.45, red)
    _add_sphere(hero_visual, Vector3(0, 2.35, 0), 0.38, skin)
    _add_capsule(hero_visual, Vector3(-0.57, 1.45, 0), 0.16, 0.9, gold)
    _add_capsule(hero_visual, Vector3(0.57, 1.45, 0), 0.16, 0.9, gold)
    _add_capsule(hero_visual, Vector3(-0.22, 0.48, 0), 0.18, 0.9, red)
    _add_capsule(hero_visual, Vector3(0.22, 0.48, 0), 0.18, 0.9, red)
    # Gold chest emblem, a simple original sunburst rather than an exact trademark logo.
    _add_sphere(hero_visual, Vector3(0, 1.55, -0.43), 0.22, gold)
    glow_mat = _material(Color(0.1, 0.72, 1.0), true)

func _physics_process(delta: float) -> void:
    blast_cooldown = maxf(0.0, blast_cooldown - delta)
    var ix := Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
    var iz := Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    ix += float(_touch("right")) - float(_touch("left"))
    iz += float(_touch("back")) - float(_touch("forward"))
    var input_vec := Vector2(ix, iz).limit_length()
    var direction := Vector3(input_vec.x, 0, input_vec.y)
    if direction.length() > 0.05:
        direction = direction.normalized()
        velocity.x = direction.x * move_speed
        velocity.z = direction.z * move_speed
        hero_visual.rotation.y = atan2(-direction.x, -direction.z)
    else:
        velocity.x = move_toward(velocity.x, 0.0, move_speed * 2.5 * delta)
        velocity.z = move_toward(velocity.z, 0.0, move_speed * 2.5 * delta)
    if Input.is_action_just_pressed("jump") and is_on_floor() and not flying:
        velocity.y = jump_velocity
    if Input.is_action_just_pressed("fly_up") or _touch("fly"):
        flying = true
    if Input.is_action_just_pressed("fly_down") or _touch("land"):
        flying = false
    if flying:
        velocity.y = fly_speed * (1.0 if Input.is_action_pressed("fly_up") or _touch("fly") else 0.0)
        if Input.is_action_pressed("fly_down") or _touch("land"):
            velocity.y = -fly_speed * 0.7
        if global_position.y < 2.0 and velocity.y < 0:
            velocity.y = 0
    else:
        if not is_on_floor():
            velocity.y -= 18.0 * delta
        else:
            velocity.y = minf(velocity.y, 0.0)
    move_and_slide()

func set_touch_action(action: String, pressed: bool) -> void:
    touch_actions[action] = pressed

func _touch(action: String) -> bool:
    return bool(touch_actions.get(action, false))

func fire_blast() -> void:
    if blast_cooldown > 0.0 or power_percent < 10.0:
        return
    blast_cooldown = 0.7
    power_percent = maxf(0.0, power_percent - 10.0)
    var orb := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.35
    sphere.height = 0.7
    orb.mesh = sphere
    orb.material_override = glow_mat
    get_tree().current_scene.add_child(orb)
    orb.global_position = global_position + Vector3(0, 1.6, 0) + -global_transform.basis.z * 1.4
    var tween := create_tween()
    tween.tween_property(orb, "global_position", orb.global_position + -global_transform.basis.z * 22.0, 0.45)
    tween.parallel().tween_property(orb, "scale", Vector3(0.15, 0.15, 0.15), 0.45)
    tween.tween_callback(orb.queue_free)

func _material(color: Color, emissive: bool = false) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    if emissive:
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = 1.4
    return mat

func _add_capsule(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material) -> void:
    var node := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = radius
    mesh.height = height
    node.mesh = mesh
    node.position = pos
    node.material_override = mat
    parent.add_child(node)

func _add_sphere(parent: Node3D, pos: Vector3, radius: float, mat: Material) -> void:
    var node := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    node.mesh = mesh
    node.position = pos
    node.material_override = mat
    parent.add_child(node)
