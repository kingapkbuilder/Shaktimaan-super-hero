extends Node3D

@onready var hero: CharacterBody3D = $Hero
@onready var status_label: Label = $UI/Status

func _ready() -> void:
    _build_city()
    _connect_touch_controls()

func _build_city() -> void:
    var ground := _box(Vector3(0, -0.5, 0), Vector3(180, 1, 180), Color(0.12, 0.16, 0.2))
    add_child(ground)
    # Roads form a simple cross-city grid; buildings are generated locally, no external assets needed.
    for i in range(-4, 5):
        var road_x := _box(Vector3(i * 22.0, 0.02, 0), Vector3(5.5, 0.05, 180), Color(0.055, 0.065, 0.08))
        add_child(road_x)
        var road_z := _box(Vector3(0, 0.03, i * 22.0), Vector3(180, 0.05, 5.5), Color(0.055, 0.065, 0.08))
        add_child(road_z)
    var rng := RandomNumberGenerator.new()
    rng.seed = 4102026
    for x in range(-4, 5):
        for z in range(-4, 5):
            if abs(x) <= 1 and abs(z) <= 1:
                continue
            var h := rng.randf_range(7.0, 28.0)
            var w := rng.randf_range(7.0, 12.0)
            var d := rng.randf_range(7.0, 12.0)
            var tint := Color.from_hsv(rng.randf_range(0.52, 0.64), rng.randf_range(0.18, 0.45), rng.randf_range(0.25, 0.55))
            var building := _box(Vector3(x * 22.0 + rng.randf_range(-3, 3), h / 2.0, z * 22.0 + rng.randf_range(-3, 3)), Vector3(w, h, d), tint)
            add_child(building)
            # Glowing rooftop beacon gives the city a distinct superhero-game look.
            if rng.randf() > 0.65:
                var beacon := _box(Vector3(building.position.x, h + 0.4, building.position.z), Vector3(0.7, 0.8, 0.7), Color(0.1, 0.75, 1.0))
                add_child(beacon)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52, -28, 0)
    sun.light_energy = 1.2
    add_child(sun)

func _box(pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    if color.b > 0.8 and color.g > 0.5:
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = 1.5
    mesh_instance.material_override = mat
    var body := StaticBody3D.new()
    body.position = Vector3.ZERO
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    mesh_instance.add_child(body)
    return mesh_instance

func _connect_touch_controls() -> void:
    var controls := $UI/TouchControls
    _bind_button(controls.get_node("Left"), "left")
    _bind_button(controls.get_node("Right"), "right")
    _bind_button(controls.get_node("Forward"), "forward")
    _bind_button(controls.get_node("Back"), "back")
    _bind_button(controls.get_node("Fly"), "fly")
    _bind_button(controls.get_node("Land"), "land")
    controls.get_node("Blast").pressed.connect(func(): hero.fire_blast())

func _bind_button(button: Button, action: String) -> void:
    button.button_down.connect(func(): hero.set_touch_action(action, true))
    button.button_up.connect(func(): hero.set_touch_action(action, false))

func _process(_delta: float) -> void:
    status_label.text = "POWER: %d%% | ENERGY BLAST: READY" % int(hero.power_percent)
