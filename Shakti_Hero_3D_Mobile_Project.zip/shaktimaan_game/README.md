# Shakti Hero 3D (mobile-first prototype)

A small, original 3D superhero sandbox prototype for Godot 4.3. It includes a procedural city blockout, a simple red-and-gold hero, flight, energy-orb effect, and touch controls. This is a playable starting point, not a finished GTA-scale game.

## Open on a phone
1. Install the official Godot Editor for Android from Godot's official download page / Play Store listing if available for your device.
2. Extract this ZIP into a folder on your phone.
3. In Godot, import the `project.godot` file and run the project.

## Build Android APK with GitHub Actions
The workflow in `.github/workflows/android-apk.yml` is a starting point for a headless export. It expects an Android export preset and Godot Android export templates. The ZIP includes `export_presets.cfg` as a template; update the Android SDK/JDK paths and keystore/signing settings if your runner or export setup requires them. Unsigned/debug APK output is for testing only.

## Controls
- WASD / arrow keys: move (keyboard testing)
- Space: jump
- E: start flying upward; Q: land / descend
- F: energy blast
- Touch UI buttons: move, fly, land, blast

## Important
- All city buildings and the hero are generated from primitive 3D shapes, so there are no external asset downloads.
- The project uses an original generic superhero design rather than official Shaktimaan artwork, logos, voice, or other protected assets. Get permission before distributing a game using the official Shaktimaan character/name commercially.
- No guarantee of a 100% error-free APK on every device; open in Godot and test the project before release.
