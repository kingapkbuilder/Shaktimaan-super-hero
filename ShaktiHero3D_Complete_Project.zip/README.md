# Shakti Hero 3D — Mobile Prototype

Original superhero-inspired 3D prototype made with Godot 4.3.

## Gameplay
- Procedurally generated city blocks
- Third-person capsule hero
- Touch joystick
- Flight toggle and up/down buttons
- Energy blast projectile and regenerating power meter
- Android APK workflow in `.github/workflows/android-apk.yml`

## Build
Run the GitHub Actions workflow named **Build Shakti Hero 3D Android APK**. The APK is uploaded as an artifact.

This is an early prototype with procedural placeholder geometry, not a finished commercial open-world game. The project uses an original hero design and does not include official Shaktimaan assets.
