extends Node3D

var hero: CharacterBody3D
var camera: Camera3D
var speed := 12.0
var flying := false
var power := 100.0
var touch_move := Vector2.ZERO
var hud: CanvasLayer
var info: Label
var fly_button: Button
var blast_button: Button
var joystick_center := Vector2.ZERO
var joystick_active := false
var joy_dot: ColorRect
var joy_base: ColorRect

func _ready() -> void:
    _make_world()
    _make_hero()
    _make_camera()
    _make_hud()

func _make_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.025, 0.045, 0.085)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.52, 0.62, 0.82)
    env.ambient_light_energy = 0.8
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -30, 0)
    sun.light_energy = 1.4
    add_child(sun)

    _box(Vector3(0, -0.6, 0), Vector3(180, 1, 180), Color(0.09, 0.12, 0.16))
    # City blocks: deterministic layout with roads and colorful building windows.
    for x in range(-5, 6):
        for z in range(-5, 6):
            if abs(x) <= 1 or abs(z) <= 1:
                continue
            var h := float(8 + ((x * 13 + z * 7) % 18 + 18) % 18)
            var w := 5.0 + float((x + z + 20) % 3)
            var pos := Vector3(x * 13.0, h * 0.5, z * 13.0)
            var tint := Color(0.12, 0.18, 0.27)
            _box(pos, Vector3(w, h, w), tint)
            for floor_i in range(1, int(h / 2.5)):
                var win := Color(0.2, 0.8, 1.0) if (floor_i + x + z) % 3 == 0 else Color(0.95, 0.62, 0.22)
                _box(pos + Vector3(0, -h * 0.5 + floor_i * 2.3, w * 0.505), Vector3(w * 0.48, 0.35, 0.08), win)
    # Road markings
    for i in range(-8, 9):
        _box(Vector3(i * 10.0, -0.08, 0), Vector3(3.0, 0.03, 0.18), Color(0.95, 0.78, 0.25))
        _box(Vector3(0, -0.07, i * 10.0), Vector3(0.18, 0.03, 3.0), Color(0.95, 0.78, 0.25))

func _box(pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.78
    mesh.material_override = mat
    body.add_child(mesh)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    add_child(body)

func _make_hero() -> void:
    hero = CharacterBody3D.new()
    hero.position = Vector3(0, 1.4, 5)
    add_child(hero)
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.9
    var body_mesh := MeshInstance3D.new()
    body_mesh.mesh = capsule
    var red := StandardMaterial3D.new()
    red.albedo_color = Color(0.78, 0.035, 0.08)
    red.metallic = 0.25
    body_mesh.material_override = red
    hero.add_child(body_mesh)

    var chest := MeshInstance3D.new()
    var chest_mesh := SphereMesh.new()
    chest_mesh.radius = 0.31
    chest_mesh.height = 0.18
    chest.mesh = chest_mesh
    chest.position = Vector3(0, 0.12, -0.43)
    var gold := StandardMaterial3D.new()
    gold.albedo_color = Color(1.0, 0.68, 0.08)
    gold.emission_enabled = true
    gold.emission = Color(0.8, 0.28, 0.01)
    chest.material_override = gold
    hero.add_child(chest)

    var shape := CollisionShape3D.new()
    var capsule_shape := CapsuleShape3D.new()
    capsule_shape.radius = 0.48
    capsule_shape.height = 1.9
    shape.shape = capsule_shape
    hero.add_child(shape)

func _make_camera() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 4.5, 8)
    camera.rotation_degrees = Vector3(-16, 0, 0)
    camera.current = true
    hero.add_child(camera)

func _make_hud() -> void:
    hud = CanvasLayer.new()
    add_child(hud)
    var title := Label.new()
    title.text = "SHAKTI HERO 3D  •  CITY RESCUE"
    title.position = Vector2(22, 16)
    title.add_theme_font_size_override("font_size", 24)
    title.add_theme_color_override("font_color", Color(1.0, 0.78, 0.2))
    hud.add_child(title)

    info = Label.new()
    info.position = Vector2(22, 52)
    info.add_theme_font_size_override("font_size", 17)
    hud.add_child(info)

    joy_base = ColorRect.new()
    joy_base.color = Color(0.2, 0.35, 0.5, 0.45)
    joy_base.position = Vector2(35, 500)
    joy_base.size = Vector2(140, 140)
    hud.add_child(joy_base)
    joy_dot = ColorRect.new()
    joy_dot.color = Color(0.95, 0.75, 0.18, 0.9)
    joy_dot.position = Vector2(83, 548)
    joy_dot.size = Vector2(44, 44)
    hud.add_child(joy_dot)

    fly_button = Button.new()
    fly_button.text = "FLY"
    fly_button.position = Vector2(1030, 500)
    fly_button.size = Vector2(105, 58)
    hud.add_child(fly_button)
    fly_button.pressed.connect(_toggle_fly)

    var up_button := Button.new()
    up_button.text = "UP"
    up_button.position = Vector2(1030, 430)
    up_button.size = Vector2(105, 52)
    hud.add_child(up_button)
    up_button.button_down.connect(func(): flying = true)
    up_button.button_up.connect(func(): flying = false)

    var down_button := Button.new()
    down_button.text = "DOWN"
    down_button.position = Vector2(1030, 570)
    down_button.size = Vector2(105, 52)
    hud.add_child(down_button)
    down_button.button_down.connect(func(): hero.velocity.y = -6.0)

    blast_button = Button.new()
    blast_button.text = "ENERGY BLAST"
    blast_button.position = Vector2(890, 610)
    blast_button.size = Vector2(245, 55)
    hud.add_child(blast_button)
    blast_button.pressed.connect(_blast)

func _toggle_fly() -> void:
    flying = not flying
    fly_button.text = "LAND" if flying else "FLY"

func _blast() -> void:
    if power < 15.0:
        info.text = "Energy low! Wait to recharge."
        return
    power -= 15.0
    var orb := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.35
    mesh.height = 0.7
    orb.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.1, 0.75, 1.0)
    mat.emission_enabled = true
    mat.emission = Color(0.05, 0.55, 1.0)
    orb.material_override = mat
    orb.position = hero.global_position + -hero.global_basis.z * 1.5 + Vector3.UP * 0.4
    get_tree().current_scene.add_child(orb)
    var tween := create_tween()
    tween.tween_property(orb, "position", orb.position + -hero.global_basis.z * 24.0, 0.6)
    tween.tween_callback(orb.queue_free)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and event.position.x < 240 and event.position.y > 400:
            joystick_active = true
            joystick_center = joy_base.position + joy_base.size * 0.5
            _set_joy(event.position)
        elif not event.pressed:
            joystick_active = false
            touch_move = Vector2.ZERO
            joy_dot.position = joy_base.position + Vector2(48, 48)
    elif event is InputEventScreenDrag and joystick_active:
        _set_joy(event.position)

func _set_joy(p: Vector2) -> void:
    var delta := (p - joystick_center).limit_length(48)
    touch_move = Vector2(delta.x / 48.0, -delta.y / 48.0)
    joy_dot.position = joystick_center + delta - joy_dot.size * 0.5

func _physics_process(delta: float) -> void:
    if not is_instance_valid(hero):
        return
    var keys := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    var move := keys
    if touch_move.length() > 0.05:
        move = touch_move
    var direction := (hero.global_basis.x * move.x + -hero.global_basis.z * move.y).normalized()
    hero.velocity.x = direction.x * speed
    hero.velocity.z = direction.z * speed
    if flying or Input.is_action_pressed("fly_up"):
        hero.velocity.y = 5.0
    elif Input.is_action_pressed("fly_down"):
        hero.velocity.y = -5.0
    elif not hero.is_on_floor():
        hero.velocity.y -= 18.0 * delta
    else:
        hero.velocity.y = -0.1
    hero.move_and_slide()
    power = min(100.0, power + delta * 4.0)
    info.text = "FLIGHT: %s   ENERGY: %d%%   WASD / joystick to move" % ["ON" if flying else "OFF", int(power)]
    camera.global_position = camera.global_position.lerp(hero.global_position + Vector3(0, 4.0, 8.0), delta * 4.0)
    camera.look_at(hero.global_position + Vector3(0, 1.0, 0), Vector3.UP)
